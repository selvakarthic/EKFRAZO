export enum DateTypeFilter {
    TODAY  = 'today',
    LAST7DAYS = 'last7days',
    LAST30DAYS = 'last30days'
}