For running project use

--> npm install --legacy-peer-deps
--> ng serve
